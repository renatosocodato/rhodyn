# RhoDyn parameter provenance

Operation: `score_residence`
Status: `pass`
Job ID: `c6ac8d03c7600db09934`
Software version: `0.1.0`
Input rows: `62`
Input hash: `d5c72bf609953408ec5a920efd81e2a5ec9678d5cf2e4b7bdecb806f8c04a59b`

## Input schema

{
  "kind": "trajectory",
  "optional": [
    "replicate"
  ],
  "recognized": true,
  "required": [
    "cell_id",
    "time",
    "condition",
    "signal"
  ],
  "submitted_fields": [
    "cell_id",
    "time",
    "condition",
    "signal",
    "replicate"
  ]
}

## Grouping

{
  "example_groups": [
    {
      "cell_id": "sequence_00_track_1207",
      "condition": "mlci_public_segmentation_features"
    },
    {
      "cell_id": "sequence_00_track_2102",
      "condition": "mlci_public_segmentation_features"
    },
    {
      "cell_id": "sequence_00_track_2103",
      "condition": "mlci_public_segmentation_features"
    },
    {
      "cell_id": "sequence_00_track_2104",
      "condition": "mlci_public_segmentation_features"
    },
    {
      "cell_id": "sequence_00_track_23",
      "condition": "mlci_public_segmentation_features"
    }
  ],
  "observed_grouping_fields": [
    "cell_id",
    "condition",
    "replicate"
  ],
  "result_group_count": 24,
  "result_grouping_levels": [
    "cell_id",
    "condition"
  ],
  "schema_kind": "trajectory"
}

## Submitted parameters

{
  "high": 14.5,
  "low": 13.0,
  "signal_column": "signal"
}

## Effective parameters

{
  "high": 14.5,
  "low": 13.0,
  "signal_column": "signal"
}

Parameter provenance records the declared analysis choices for this run. It does not change the submitted measurements or upgrade derived summaries into direct biological mechanisms.
