# RhoDyn score_residence result

| condition | cell_id | n_points | residence_fraction | residence_time | total_time | mean_signal | max_signal | min_signal | segments |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| mlci_public_segmentation_features | sequence_00_track_1207 | 4 | 0.0 | 0 | 60.0 | 16.28648625 | 17.911011 | 15.143243 | [] |
| mlci_public_segmentation_features | sequence_00_track_2102 | 3 | 0.0 | 0 | 40.0 | 12.897205 | 13.110561 | 12.648184 | [{'start': 40.0, 'end': 40.0, 'duration': 0.0}] |
| mlci_public_segmentation_features | sequence_00_track_2103 | 4 | 0.6666666666666666 | 40.0 | 60.0 | 13.6667445 | 14.60347 | 12.560081 | [{'start': 80.0, 'end': 100.0, 'duration': 20.0}] |
| mlci_public_segmentation_features | sequence_00_track_2104 | 1 | 0.0 | 0.0 | 1.0 | 15.473077 | 15.473077 | 15.473077 | [] |
| mlci_public_segmentation_features | sequence_00_track_23 | 4 | 0.6666666666666666 | 40.0 | 60.0 | 13.32588025 | 13.822222 | 12.841432 | [{'start': 20.0, 'end': 60.0, 'duration': 40.0}] |
| mlci_public_segmentation_features | sequence_00_track_24 | 3 | 1.0 | 40.0 | 40.0 | 13.609733 | 13.877266 | 13.147793 | [{'start': 80.0, 'end': 120.0, 'duration': 40.0}] |
| mlci_public_segmentation_features | sequence_00_track_25 | 1 | 0.0 | 0.0 | 1.0 | 16.009132 | 16.009132 | 16.009132 | [] |
| mlci_public_segmentation_features | sequence_00_track_3057 | 1 | 0.0 | 0.0 | 1.0 | 15.645914 | 15.645914 | 15.645914 | [] |
| mlci_public_segmentation_features | sequence_00_track_3716 | 5 | 0.0 | 0 | 80.0 | 16.3232582 | 17.039437 | 14.88563 | [] |
| mlci_public_segmentation_features | sequence_00_track_734 | 1 | 1.0 | 1.0 | 1.0 | 13.408389 | 13.408389 | 13.408389 | [{'start': 140.0, 'end': 140.0, 'duration': 0.0}] |
| mlci_public_segmentation_features | sequence_01_track_1223 | 2 | 0.0 | 0 | 20.0 | 23.3576855 | 24.806706 | 21.908665 | [] |
| mlci_public_segmentation_features | sequence_01_track_2166 | 4 | 0.0 | 0 | 60.0 | 17.109854 | 19.354796 | 14.868664 | [] |
| mlci_public_segmentation_features | sequence_01_track_2167 | 2 | 0.0 | 0 | 20.0 | 18.112944499999998 | 18.145729 | 18.08016 | [] |
| mlci_public_segmentation_features | sequence_01_track_2408 | 2 | 0.0 | 0 | 20.0 | 26.421761 | 27.704633 | 25.138889 | [] |
| mlci_public_segmentation_features | sequence_01_track_30 | 2 | 1.0 | 20.0 | 20.0 | 13.570703 | 13.656977 | 13.484429 | [{'start': 0.0, 'end': 20.0, 'duration': 20.0}] |
| mlci_public_segmentation_features | sequence_01_track_31 | 4 | 0.0 | 0 | 60.0 | 16.67572475 | 17.882581 | 15.478351 | [] |
| mlci_public_segmentation_features | sequence_01_track_32 | 2 | 0.0 | 0 | 20.0 | 16.869038500000002 | 17.615953 | 16.122124 | [] |
| mlci_public_segmentation_features | sequence_01_track_3387 | 3 | 1.0 | 40.0 | 40.0 | 14.357408666666666 | 14.874837 | 13.894737 | [{'start': 0.0, 'end': 20.0, 'duration': 20.0}] |
| mlci_public_segmentation_features | sequence_01_track_3388 | 3 | 0.0 | 0 | 40.0 | 16.241455333333334 | 16.742147 | 15.90625 | [] |
| mlci_public_segmentation_features | sequence_01_track_3389 | 2 | 0.0 | 0 | 20.0 | 17.8580665 | 18.638752 | 17.077381 | [] |
| mlci_public_segmentation_features | sequence_01_track_4088 | 2 | 0.0 | 0 | 20.0 | 17.4085225 | 17.586998 | 17.230047 | [] |
| mlci_public_segmentation_features | sequence_01_track_4993 | 3 | 0.0 | 0 | 40.0 | 16.501773 | 17.176786 | 15.334783 | [] |
| mlci_public_segmentation_features | sequence_01_track_4994 | 2 | 0.0 | 0 | 20.0 | 21.783625999999998 | 21.978723 | 21.588529 | [] |
| mlci_public_segmentation_features | sequence_01_track_5349 | 2 | 0.0 | 0 | 20.0 | 18.225774 | 18.700971 | 17.750577 | [] |
