# RhoDyn parameter provenance

Operation: `decide_coupling`
Status: `pass`
Job ID: `5f8bd2b80e36868a5286`
Software version: `0.1.0`
Input rows: `2`
Input hash: `79d6c89310f83492e97995510e65ce5d0b649749ac6f1992f8d27f4e43c94760`

## Input schema

{
  "kind": "coupling",
  "optional": [
    "rope_mass"
  ],
  "recognized": true,
  "required": [
    "contrast",
    "estimate",
    "ci_low",
    "ci_high",
    "margin"
  ],
  "submitted_fields": [
    "contrast",
    "estimate",
    "ci_low",
    "ci_high",
    "margin",
    "rope_mass"
  ]
}

## Grouping

{
  "example_groups": [],
  "observed_grouping_fields": [
    "contrast"
  ],
  "result_group_count": 0,
  "result_grouping_levels": [],
  "schema_kind": "coupling"
}

## Submitted parameters

{
  "rope_threshold": 0.95
}

## Effective parameters

{
  "rope_threshold": 0.95
}

Parameter provenance records the declared analysis choices for this run. It does not change the submitted measurements or upgrade derived summaries into direct biological mechanisms.
